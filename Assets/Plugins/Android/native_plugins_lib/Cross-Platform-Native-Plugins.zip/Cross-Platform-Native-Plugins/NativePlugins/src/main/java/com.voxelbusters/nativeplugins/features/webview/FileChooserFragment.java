package com.voxelbusters.nativeplugins.features.webview;

import android.Manifest;
import android.app.Fragment;
import android.app.FragmentTransaction;

import android.content.Intent;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.ResultReceiver;

import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.features.medialibrary.MediaLibraryActivity;
import com.voxelbusters.nativeplugins.helpers.interfaces.IPermissionRequestCallback;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.FileUtility;
import com.voxelbusters.nativeplugins.utilities.IntentUtilities;
import com.voxelbusters.nativeplugins.utilities.PermissionUtility;

import java.io.File;
import java.net.URI;


import static android.app.Activity.RESULT_OK;

public class FileChooserFragment extends Fragment {
    public static final int REQUEST_CODE_UNKNOWN = -1;
    public static final int REQUEST_CODE_FILE_CHOOSER = 111;
    private String currentAction = "";
    private Uri cameraFileUri = null;
    private ResultReceiver callback;

    public FileChooserFragment() {
        callback = null;
    }

    public void setCallback(ResultReceiver callback) {
        this.callback = callback;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent requiredIntent = null;
        final int requestCode = REQUEST_CODE_FILE_CHOOSER;

        Bundle bundleInfo = getArguments();
        String type = getArguments().getString(Keys.TYPE);
        final String mimeType = bundleInfo.getString(Keys.WebView.ACCEPTABLE_DATA_MIME);

        currentAction = type;

        PermissionUtility.requestPermission(Manifest.permission.CAMERA, Keys.MediaLibrary.CAMERA_PERMISSION_REASON, new IPermissionRequestCallback() {
            @Override
            public void onPermissionGrant()
            {
                Intent galleryIntent = IntentUtilities.getGalleryIntent(mimeType);

                cameraFileUri = FileUtility.createSharingFileUri(FileChooserFragment.this.getActivity(), null, 0, CommonDefines.SHARING_DIR, "CameraCapture.jpg");

                Intent extraIntent = IntentUtilities.getCameraIntent(FileChooserFragment.this.getActivity(), cameraFileUri);

                Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                chooserIntent.putExtra(Intent.EXTRA_INTENT, galleryIntent);
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{extraIntent});
                startActivityForResult(Intent.createChooser(chooserIntent, ""), requestCode);
            }

            @Override
            public void onPermissionDeny()
            {
                setCallbackResult(Uri.EMPTY);
            }
        });
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();

        setCallbackResult(Uri.EMPTY);
    }

    private void setCallbackResult(Uri value)
    {
        if(callback != null)
        {
            Bundle bundle = new Bundle();
            bundle.putParcelable("DATA", value);
            callback.send(0, bundle);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        switch (requestCode) {
            case REQUEST_CODE_FILE_CHOOSER:

                if (resultCode == RESULT_OK && intent != null) {
                    Uri value = intent.getData();

                    if (value == null)
                    {
                        value = cameraFileUri;
                    }

                    Debug.log("FileChooser", "Uri:" + value + " cameraFileUri : " + cameraFileUri);
                    setCallbackResult(value);

                    //Reset callback to handle onDestroy case when there are no activity reuslts.
                    callback = null;
                    break;
                }
        }


        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.remove(this);
        fragmentTransaction.commit();
    }
}
