package com.voxelbusters.nativeplugins.features.gameservices.serviceprovider.google;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesActivityResultCodes;
import com.voxelbusters.androidnativeplugin.R;
import com.voxelbusters.nativeplugins.NativePluginHelper;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.features.gameservices.GameServicesHandler;
import com.voxelbusters.nativeplugins.features.gameservices.serviceprovider.google.util.BaseGameUtils;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.StringUtility;

public class GooglePlayGameUIActivity extends Activity implements DialogInterface.OnDismissListener
{
	private final String	TAG								= "GooglePlayGameUIActivity";
	private  final int		REQUEST_CODE_UNKNOWN			= -1;
	private final int		REQUEST_CODE_CONNECTION_RESOLVE	= 1000;
	private final int		REQUEST_CODE_SHOW_ACHIEVEMENTS	= 1001;
	private final int		REQUEST_CODE_SHOW_LEADERBOARDS	= 1002;
	private final int 		REQUEST_CODE_GET_SERVER_AUTH_CODE	= 1003;
	GooglePlayGameService	service;

	boolean hasActivityResult=false;
	int currentRequestCode = REQUEST_CODE_UNKNOWN;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		service = GooglePlayGameService.getInstance();

		if (service == null)
		{
			finish();
			return;
		}

		Intent intent = getIntent();


		String type = intent.getStringExtra(Keys.TYPE);

		if (type.equals(Keys.GameServices.ON_CONNECTION_FAILURE))
		{
			int resultCode = intent.getIntExtra(Keys.GameServices.RESULT_CODE, 0);
			PendingIntent pendingIntent = intent.getParcelableExtra(Keys.GameServices.PENDING_INTENT);
			ConnectionResult result = new ConnectionResult(resultCode, pendingIntent);

			String displayString = intent.getStringExtra(Keys.GameServices.DISPLAY_STRING);

			if ((service.getApiService() == null) || !BaseGameUtils.resolveConnectionFailure(this, service.getApiService(), result, REQUEST_CODE_CONNECTION_RESOLVE, displayString))
			{
				service.finishedResolvingConnectionFailure();
				service.reportConnectionFailed();
				finish();
			}
		}
		else if (type.equals(Keys.GameServices.SHOW_ACHIEVEMENTS))
		{
			launchActivityForResult(Games.Achievements.getAchievementsIntent(service.getApiService()), REQUEST_CODE_SHOW_ACHIEVEMENTS);
		}
		else if (type.equals(Keys.GameServices.SHOW_LEADERBOARDS)) {
			Intent requiredIntent = null;
			String leaderboardId = intent.getStringExtra(Keys.GameServices.LEADERBOARD_ID);
			String timeSpan = intent.getStringExtra(Keys.GameServices.TIME_SPAN);

			if (!StringUtility.isNullOrEmpty(leaderboardId))//If not null load specific leaderboard. Else load all leaderboards.
			{
				requiredIntent = Games.Leaderboards.getLeaderboardIntent(service.getApiService(), leaderboardId, Integer.parseInt(timeSpan));
			} else {
				requiredIntent = Games.Leaderboards.getAllLeaderboardsIntent(service.getApiService());
			}

			launchActivityForResult(requiredIntent, REQUEST_CODE_SHOW_LEADERBOARDS);

		}
		else
		{
			Debug.error(TAG, "Type unspecified for this intent");
		}
	}

	void launchActivityForResult(Intent intent, int requestCode)
	{
		currentRequestCode = requestCode;
		startActivityForResult(intent, requestCode);
	}


	@Override
	public void onDestroy()
	{
		if(currentRequestCode != REQUEST_CODE_UNKNOWN)
		{
			if(!hasActivityResult)
			{
				sendResults(REQUEST_CODE_UNKNOWN);
			}
		}
		super.onDestroy();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		boolean delayActivityClose = false;

		if (requestCode == REQUEST_CODE_CONNECTION_RESOLVE)
		{
			Debug.log(CommonDefines.GAME_SERVICES_TAG, "Request Code : " + requestCode + " Result Code : " + resultCode);

			if (service != null)
			{
				service.finishedResolvingConnectionFailure();
				if (resultCode == RESULT_OK) {
					service.signIn();
				} else {
					if (GameServicesHandler.getInstance().getShowDefaultErrorDialogs())
					{
						BaseGameUtils.showActivityResultError(this, requestCode, resultCode, R.string.gameservices_sign_in_failed);
						delayActivityClose = true;
					}
					else
					{
						service.reportConnectionFailed();
					}
				}
			}
		}
		else
		{
			hasActivityResult = true;
			sendResults(requestCode);
		}

		if (!delayActivityClose)
		{
			finish();
		}
	}

	void sendResults (int resultCode)
	{
		if (currentRequestCode == REQUEST_CODE_SHOW_ACHIEVEMENTS)
		{
			Debug.log(TAG, "onActivityResult from Show Achievements");

			if (service != null) {
				service.reportAchievementsUIClosed();

				if (resultCode == GamesActivityResultCodes.RESULT_RECONNECT_REQUIRED)//When clicked on signout from UI.
				{
					service.getApiService().disconnect();
				}
			}

		}
		else if (currentRequestCode == REQUEST_CODE_SHOW_LEADERBOARDS)
		{
			Debug.log(TAG, "onActivityResult from Show specific Leaderboard/All Leaderboards");
			if (service != null) {
				service.reportLeaderboardsUIClosed();

				if (resultCode == GamesActivityResultCodes.RESULT_RECONNECT_REQUIRED)//When clicked on signout from UI.
				{
					service.getApiService().disconnect();
				}
			}
		}
		else
		{
			Debug.log(TAG, "Unknown request code!");
		}


	}

	@Override
	public void onDismiss(DialogInterface dialog)
	{
		if (service != null)
			service.reportConnectionFailed();

		finish();
	}
}
