package com.voxelbusters.nativeplugins.features.gameservices;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.android.gms.games.leaderboard.LeaderboardVariant;
import com.voxelbusters.nativeplugins.NativePluginHelper;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.defines.UnityDefines;
import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.AchievementData;
import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.Score;
import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.User;
import com.voxelbusters.nativeplugins.features.gameservices.core.interfaces.IGameServices;
import com.voxelbusters.nativeplugins.features.gameservices.core.interfaces.IGameServicesAuthListener;
import com.voxelbusters.nativeplugins.features.gameservices.core.interfaces.IGameServicesPlayerListener;
import com.voxelbusters.nativeplugins.features.gameservices.serviceprovider.google.GooglePlayGameService;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.JSONUtility;
import com.voxelbusters.nativeplugins.utilities.StringUtility;

import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;

public class GameServicesHandler implements IGameServicesPlayerListener, IGameServicesAuthListener
{
	// Create singleton instance
	private static GameServicesHandler	INSTANCE;

	private final IGameServices			service;
	HashMap<String, Integer>			keyMap	= new HashMap<String, Integer>();

	private boolean showDefaultErrorDialogs;
	private boolean autoSignInUser;

	public static GameServicesHandler getInstance()
	{
		if (INSTANCE == null)
		{
			INSTANCE = new GameServicesHandler();
		}
		return INSTANCE;
	}

	// Make constructor private for making singleton interface
	private GameServicesHandler()
	{
		service = GooglePlayGameService.getInstance(NativePluginHelper.getCurrentContext());

		keyMap.put(Keys.GameServices.TIME_SCOPE_ALL_TIME, LeaderboardVariant.TIME_SPAN_ALL_TIME);
		keyMap.put(Keys.GameServices.TIME_SCOPE_WEEK, LeaderboardVariant.TIME_SPAN_WEEKLY);
		keyMap.put(Keys.GameServices.TIME_SCOPE_TODAY, LeaderboardVariant.TIME_SPAN_DAILY);

		keyMap.put(Keys.GameServices.USER_SCOPE_FRIENDS, LeaderboardVariant.COLLECTION_SOCIAL);
		keyMap.put(Keys.GameServices.USER_SCOPE_GLOBAL, LeaderboardVariant.COLLECTION_PUBLIC);
	}

	public void setShowDefaultErrorDialogs(boolean show)
	{
		showDefaultErrorDialogs = show;
	}

	//Availability
	public boolean isServiceAvailable()
	{
		boolean isAvailable = service.isAvailable();

		if (!isAvailable)
		{
			Debug.error(CommonDefines.GAME_SERVICES_TAG, "Service not functional. Either not avaialble or update required.");
		}

		return isAvailable;
	}

	public void register(boolean useCloudServices)
	{
		register(useCloudServices, true);
	}

	public void register(boolean useCloudServices, boolean allowAutoLogin)
	{
		service.register(useCloudServices);
		service.addListener(this, this);

		if (allowAutoLogin)
		{
			if (getAutoSignInStatus()) {
				autoSignInUser();
			}
		}
	}

	public boolean isSignedIn()
	{
		return service.isSignedIn();
	}

	//Achievements
	public void loadAchievementDescriptions()
	{
		service.loadAllAchievements();
	}

	public void loadAchievements()
	{
		service.loadUserAchievements();
	}

	public String getAchievement(String achievementId)
	{
		AchievementData achievementData = service.getAchievementData(achievementId);
		return JSONUtility.getJSONString(achievementData.getHashMap());
	}

	public void reportProgress(String instanceId, String achievementId, int points, boolean immediate)
	{
		service.reportProgress(instanceId, achievementId, points, immediate);
	}

	public void showAchievementsUi()
	{
		service.showAchievementsUi();
	}

	//Leaderboards

	public void loadTopScores(final String instanceId, final String leaderboardId, final String timeScope, final String userScope, final int count)
	{
		Thread thread = new Thread()
			{
				@Override
				public void run()
				{
					service.loadTopScores(instanceId, leaderboardId, keyMap.get(timeScope), keyMap.get(userScope), count);
				}
			};
		thread.start();
	}

	public void loadPlayerCenteredScores(final String instanceId, final String leaderboardId, final String timeScope, final String userScope, final int count)
	{
		Thread thread = new Thread()
			{
				@Override
				public void run()
				{
					service.loadPlayerCenteredScores(instanceId, leaderboardId, keyMap.get(timeScope), keyMap.get(userScope), count);
				}
			};
		thread.start();

	}

	public void loadMoreScores(final String instanceId, final String leaderboardId, final int direction, final int count)
	{

		Thread thread = new Thread()
			{
				@Override
				public void run()
				{
					service.loadMoreScrores(instanceId, leaderboardId, direction, count);
				}
			};
		thread.start();
	}

	public void reportScore(String instanceId, String leaderboardId, long score, boolean immediate)
	{
		service.reportScore(instanceId, leaderboardId, score, immediate);
	}

	public void showLeaderboardsUi(String leaderboardId, String timeScope)
	{
		service.showLeaderboardsUi(leaderboardId, keyMap.get(timeScope));
	}

	//Users API
	public void loadUsers(String instanceId, String userIdListJsonStr)
	{
		String[] userList = StringUtility.convertJsonStringToStringArray(userIdListJsonStr);
		service.loadUsers(instanceId, userList);
	}

	public void loadLocalUserFriends(boolean loadFromServer)
	{
		service.loadLocalPlayerFriends(loadFromServer);
	}

	public void authenticateLocalUser()
	{
		autoSignInUser = false;
		service.signIn();
	}

	private void autoSignInUser()
	{
		autoSignInUser = true;
		service.signIn();
	}

	public void signOut()
	{
		service.signOut();
		SaveAutoSignInStatus(false);
	}

	public void loadProfilePicture(final String requestId, final String uriString)
	{

		Runnable runnable = new Runnable()
			{
				@Override
				public void run()
				{
					service.loadProfileImage(requestId, uriString);
				}
			};

		NativePluginHelper.executeOnUIThread(runnable);
	}

	public void loadExternalAuthenticationDetails(String serverClienId)
	{
		service.requestAuthToken(serverClienId);
	}

	@Override
	public void onConnected(User localUser, String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		if (error != null)
		{
			data.put(Keys.GameServices.ERROR, error);
		}
		data.put(Keys.GameServices.LOCAL_USER_INFO, localUser.getHashMap());
		NativePluginHelper.sendMessage(UnityDefines.GameServices.AUTHENTICATION_FINISHED, data);


		// Save here that user connected and from next time we can connect him automatically.
		SaveAutoSignInStatus(true);
	}

	@Override
	public void onDisConnected()
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Keys.GameServices.ERROR, "Disconnected!");
		NativePluginHelper.sendMessage(UnityDefines.GameServices.AUTHENTICATION_FINISHED, data);
		SaveAutoSignInStatus(false);
	}

	@Override
	public void onConnectionSuspended()
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Keys.GameServices.ERROR, "Connection Suspended!");
		NativePluginHelper.sendMessage(UnityDefines.GameServices.AUTHENTICATION_FINISHED, data);
	}

	@Override
	public void onConnectionFailure()
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Keys.GameServices.ERROR, "Connection Failure while connecting!");
		NativePluginHelper.sendMessage(UnityDefines.GameServices.AUTHENTICATION_FINISHED, data);
	}

	@Override
	public void onLoadingScores(String instanceId, Score localPlayerScore, ArrayList<Score> scores, String error)
	{

		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Keys.GameServices.INSTANCE_ID, instanceId);
		if (error != null)
		{
			data.put(Keys.GameServices.ERROR, error);
		}
		else
		{
			HashMap<String, Object> leaderboardInfo = new HashMap<String, Object>();

			leaderboardInfo.put(Keys.GameServices.LEADERBOARD_LOCAL_SCORE, (localPlayerScore == null) ? null :localPlayerScore.getHashMap());
			leaderboardInfo.put(Keys.GameServices.LEADERBOARD_SCORES_LIST, (scores == null) ? null : getConvertedScoreList(scores));

			data.put(Keys.GameServices.LEADERBOARD_INFO, leaderboardInfo);
		}

		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_SCORES, data);
	}

	@Override
	public void onLoadAchievementDetails(ArrayList<AchievementData> achievements, String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		if (!StringUtility.isNullOrEmpty(error))
		{
			data.put(Keys.GameServices.ERROR, error);
		}

		data.put(Keys.GameServices.ACHIEVEMENTS_LIST, getConvertedAchievementsList(achievements));

		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_ACHIEVEMENT_DESCRIPTIONS, data);
	}

	@Override
	public void onLoadUserAchievements(ArrayList<AchievementData> achievements, String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();

		if (!StringUtility.isNullOrEmpty(error))
		{
			data.put(Keys.GameServices.ERROR, error);
		}
		data.put(Keys.GameServices.ACHIEVEMENTS_LIST, getConvertedAchievementsList(achievements));

		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_ACHIEVEMENTS, data);
	}

	@Override
	public void onLoadLocalUserFriendsDetails(ArrayList<User> friendsData, String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		if (error != null)
		{
			data.put(Keys.GameServices.ERROR, error);
		}
		data.put(Keys.GameServices.LOCAL_USER_FRIENDS, (friendsData == null) ? null : getConvertedUserList(friendsData));
		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_LOCAL_USER_FRIENDS_REQUEST, data);
	}

	@Override
	public void onLoadLocalUserDetails(User userHash)
	{
		//Send here details of local player
	}

	@Override
	public void onLoadUserProfiles(String instanceId, ArrayList<User> users, String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		if (error != null)
		{
			data.put(Keys.GameServices.ERROR, error);
		}
		data.put(Keys.GameServices.INSTANCE_ID, instanceId);

		data.put(Keys.GameServices.USERS_LIST, (users == null) ? null : getConvertedUserList(users));

		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_USER_PROFILES_LIST, data);
	}

	@Override
	public void onLoadProfilePicture(String requestId, String filePath, String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		if (error != null)
		{
			data.put(Keys.GameServices.ERROR, error);
		}
		data.put(Keys.GameServices.INSTANCE_ID, requestId);
		data.put(Keys.GameServices.IMAGE_FILE_PATH, filePath);

		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_PICTURE_LOAD_REQUEST, data);
	}

	@Override
	public void onReportProgress(String instanceID, AchievementData achievementData, String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Keys.GameServices.INSTANCE_ID, instanceID);
		if (achievementData != null)
		{
			data.put(Keys.GameServices.ACHIEVEMENT_INFO, achievementData.getHashMap());
		}

		if (error != null)
		{
			data.put(Keys.GameServices.ERROR, error);
		}

		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_REPORT_PROGRESS, data);
	}

	@Override
	public void onReportScore(String instanceId, Score score, String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put(Keys.GameServices.INSTANCE_ID, instanceId);

		if (score != null)
		{
			data.put(Keys.GameServices.SCORE_INFO, score.getHashMap());
		}

		if (error != null)
		{
			data.put(Keys.GameServices.ERROR, error);
		}

		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_REPORT_SCORE, data);
	}

	@Override
	public void onAchievementsUIClosed()
	{
		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_ACHIEVEMENTS_UI_CLOSED);
	}

	@Override
	public void onLeaderboardsUIClosed()
	{
		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_LEADERBOARDS_UI_CLOSED);
	}

	@Override
	public void onSignOut(String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();

		if (!StringUtility.isNullOrEmpty(error))
		{
			data.put(Keys.GameServices.ERROR, error);
		}

		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_SIGN_OUT_STATUS, data);
	}

	@Override
	public void onReceivingExternalAuthenticationDetails(String authCode, String error)
	{
		HashMap<String, Object> data = new HashMap<String, Object>();

		if (!StringUtility.isNullOrEmpty(error))
		{
			data.put(Keys.GameServices.ERROR, error);
		}

		HashMap<String, Object> credentials = new HashMap<String, Object>();

		credentials.put(Keys.GameServices.SERVER_AUTH_CODE, authCode);

		data.put(Keys.GameServices.EXTERNAL_CREDENTIALS_DATA, credentials);

		NativePluginHelper.sendMessage(UnityDefines.GameServices.RECEIVED_EXTERNAL_AUTHENTICATION_DETAILS, data);
	}

	ArrayList<HashMap<String, Object>> getConvertedUserList(ArrayList<User> users)
	{
		ArrayList<HashMap<String, Object>> userList = new ArrayList<HashMap<String, Object>>();

		if (users != null) {
			for (int i = 0; i < users.size(); i++) {
				userList.add(users.get(i).getHashMap());
			}
		}

		return userList;
	}

	ArrayList<HashMap<String, Object>> getConvertedScoreList(ArrayList<Score> scores)
	{
		ArrayList<HashMap<String, Object>> userList = new ArrayList<HashMap<String, Object>>();
		if (scores != null)
		{
			for (int i = 0; i < scores.size(); i++) {
				userList.add(scores.get(i).getHashMap());
			}
		}

		return userList;
	}

	ArrayList<HashMap<String, Object>> getConvertedAchievementsList(ArrayList<AchievementData> list)
	{
		ArrayList<HashMap<String, Object>> dataList = new ArrayList<HashMap<String, Object>>();

		if (list != null)
		{
			for (int i = 0; i < list.size(); i++) {
				dataList.add(list.get(i).getHashMap());
			}
		}
		return dataList;
	}


	// Getter calls
	public boolean getShowDefaultErrorDialogs()
	{
		return  showDefaultErrorDialogs;
	}

	public boolean isAutoLogin()
	{
		return  autoSignInUser;
	}

	private boolean getAutoSignInStatus()
	{
		Context context = NativePluginHelper.getCurrentContext();
		SharedPreferences sharedPref = context.getSharedPreferences(Keys.GameServices.SAVED_KEYS_FILE, Context.MODE_PRIVATE);
		boolean autoSignInAllowed = sharedPref.getBoolean(Keys.GameServices.SAVED_AUTO_SIGN_IN_STATUS, false);
		return  autoSignInAllowed;
	}

	private void SaveAutoSignInStatus(boolean status)
	{
		Context context = NativePluginHelper.getCurrentContext();
		SharedPreferences sharedPref = context.getSharedPreferences(Keys.GameServices.SAVED_KEYS_FILE, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPref.edit();
		editor.putBoolean(Keys.GameServices.SAVED_AUTO_SIGN_IN_STATUS, status);
		editor.commit();
	}
}