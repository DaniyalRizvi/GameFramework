package com.voxelbusters.nativeplugins.utilities;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.media.ExifInterface;
import android.support.v4.content.FileProvider;
import android.webkit.MimeTypeMap;

import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class FileUtility
{
	public final static int	IMAGE_QUALITY	= 100;	// TODO

	public static String getSavedFile(byte[] data, int length, File destinationDir, String destinationFileName, boolean addScheme)
	{
		return getSavedFile(data, length, destinationDir, destinationFileName, addScheme, true);
	}

	private static String getSavedFile(byte[] data, int length, File destinationDir, String destinationFileName, boolean addScheme, boolean needsGlobalAccess)
	{
		String destPath = null;

		//Check a head and create if it doesn't exist
		createDirectoriesIfUnAvailable(destinationDir.getAbsolutePath());

		File destinationFile = new File(destinationDir, destinationFileName);

		if (destinationFile.exists())
		{
			destinationFile.delete();

			try
			{
				destinationFile.createNewFile();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}

		}

		if (needsGlobalAccess)
		{
			destinationFile.setReadable(true, false);
			destinationFile.setWritable(true, false);
		}

		FileOutputStream outputStream = null;

		try
		{
			outputStream = new FileOutputStream(destinationFile);
			if (data != null)
			{
				outputStream.write(data);
			}
			outputStream.close();
			destPath = destinationFile.getAbsolutePath();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		if ((destPath != null) && addScheme)
		{
			destPath = "file://" + destPath;
		}

		return destPath;
	}

	private static void createDirectoriesIfUnAvailable(String dir)
	{
		File file = new File(dir);
		if (!file.exists())
		{
			file.mkdirs();
		}
	}

	public static ByteArrayOutputStream getBitmapStreamFromLocalDirectory(String path)
	{
		File file = new File(path);
		Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		bitmap.compress(Bitmap.CompressFormat.PNG, IMAGE_QUALITY, stream);

		return stream;
	}

	private static void createPathIfUnAvailable(File destinationDir, File destinationFile)
	{
		if (!destinationFile.exists())
		{
			try
			{
				destinationDir.mkdirs();
				destinationFile.createNewFile();
			}
			catch (IOException e)
			{
				Debug.error(CommonDefines.FILE_UTILS_TAG, "Creating file failed!");
				e.printStackTrace();
			}
		}
	}

	public static String createFileFromStream(InputStream stream, File destinationDir, String destinationFileName)
	{
		String absoluteDestinationPath = null;
		File destinationFile = new File(destinationDir, destinationFileName);

		createPathIfUnAvailable(destinationDir, destinationFile);

		try
		{
			OutputStream out = new FileOutputStream(destinationFile);
			byte[] buf = new byte[1024];
			int length;
			while ((length = stream.read(buf)) > 0)
			{
				out.write(buf, 0, length);
			}
			out.close();
			stream.close();
			buf = null;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		absoluteDestinationPath = destinationFile.getAbsolutePath();

		return absoluteDestinationPath;
	}

	public static String getScaledImagePathFromBitmap(Bitmap bitmap, File destinationDir, String destinationFileName, float scaleFactor)
	{
		return getScaledImagePathFromBitmap(bitmap, destinationDir, destinationFileName, scaleFactor, new ExifInfo(0, false));
	}

	public static String getScaledImagePathFromBitmap(Bitmap bitmap, File destinationDir, String destinationFileName, float scaleFactor, ExifInfo exifInfo)
	{
		String absoluteDestinationPath = null;

		int width = 0;
		int height = 0;

		if(bitmap == null)
		{
			return null;
		}
		else
		{
			width = bitmap.getWidth();
			height = bitmap.getHeight();
		}

		if ((width != 0) && (height != 0))
		{
			// Below method returns same bitmap if no change in
			// width
			// and height (scaleFactor = 1.0f), which is nice!

			// Create matrix
			Matrix matrix = new Matrix();

			// Resize
			matrix.postScale(scaleFactor, scaleFactor);

			// Rotate
			matrix.postRotate(exifInfo.getRotation());

			// Check if there is any flip required
			matrix.postScale(exifInfo.isFlipped() ? -1.0f : 1.0f, 1);

			try
			{
				Bitmap transformedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);//Bitmap.createScaledBitmap(bitmap, scaledWidth, scaledHeight, true);
				absoluteDestinationPath = saveBitmap(transformedBitmap, destinationDir, destinationFileName, true);
			}
			catch (Throwable throwable)
			{
				Debug.error("FileUtility", "Error while creating bitmap" + throwable);
			}
		}
		else
		{
			Debug.error(CommonDefines.FILE_UTILS_TAG, "Width and height should be greater than zero. Returning null reference");
		}

		if (bitmap != null && !bitmap.isRecycled())
			bitmap.recycle();

		return absoluteDestinationPath;
	}

	public static  void grantPermissions (Context context , Uri fileUri, int permissions)
	{
		context.grantUriPermission(context.getPackageName(), fileUri, permissions);
	}

	private static String getScaledImagePath(String sourcePath, File destinationDir, String destinationFileName, float scaleFactor, boolean deleteSource)
	{
		String absoluteDestinationPath = null;

		// Create a new bitmap based on the scale factor specified.Return
		// original if scale factor is 1.0f
		File sourceImageFile = new File(sourcePath);

		Bitmap bitmap = BitmapFactory.decodeFile(sourceImageFile.getAbsolutePath());

		absoluteDestinationPath = getScaledImagePathFromBitmap(bitmap, destinationDir, destinationFileName, scaleFactor);

		if (deleteSource)
		{
			sourceImageFile.delete();
		}

		return absoluteDestinationPath;
	}

	public static String getSavedLocalFileFromUri(Context context, Uri uri, String folderName, String targetFileName)
	{
		return getSavedFileFromUri(context, uri, context.getDir(folderName, Context.MODE_PRIVATE), targetFileName);
	}

	private static String getSavedFileFromUri(Context context, Uri uri, File targetDirectory, String targetFileName)
	{

		ByteArrayOutputStream byteStream = null;

		byte[] byteArray = null;

		ContentResolver resolver = context.getContentResolver();;
		try
		{
			InputStream inputStream = resolver.openInputStream(uri);
			byteStream = new ByteArrayOutputStream();

			byte[] buffer = new byte[1024];
			while ((inputStream.read(buffer)) != -1)
			{
				byteStream.write(buffer);
			}

			byteStream.flush();
			byteArray = byteStream.toByteArray();

		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		if (byteStream != null)
		{
			try
			{
				byteStream.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}

		if (byteArray != null)
		{
			return getSavedFile(byteArray, byteArray.length, targetDirectory, targetFileName, true);
		}
		else
		{
			return null;
		}
	}

	public static Uri createSharingFileUri(Context context, byte[] byteArray, int byteArrayLength, String dirName, String fileName)
	{

		boolean hasExternalDir = ApplicationUtility.hasExternalStorageWritable(context);

		// Create a bitmap and save it
		String imagePath = FileUtility.getSavedFile(byteArray, byteArrayLength, ApplicationUtility.getLocalSaveDirectory(context, dirName), fileName, false);

		Debug.log(CommonDefines.SHARING_TAG, "Saving temp at " + imagePath);
		Uri imageUri = null;

		if (!StringUtility.isNullOrEmpty(imagePath))
		{
			//Check if external directory exists. if so use that.
			//if (!hasExternalDir)
			{
				imageUri = FileProvider.getUriForFile(context, ApplicationUtility.getFileProviderAuthoityName(context), new File(imagePath));
			}
			/*else
			{
				imageUri = Uri.fromFile(new File(imagePath));
			}*/

			context.grantUriPermission(ApplicationUtility.getPackageName(context), imageUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
		}

		return imageUri;
	}

	public  static File getFileProviderUriFile (Context context, String dirName, String fileName)
	{
		File file = new File(ApplicationUtility.getLocalSaveDirectory(context, dirName), fileName);
		return  file;
	}

	public static String saveBitmap(Bitmap bitmap, File destinationDir, String destinationFileName, boolean freeBitmap)
	{
		File destinationImageFile = new File(destinationDir, destinationFileName);
		createPathIfUnAvailable(destinationDir, destinationImageFile);

		OutputStream outStream = null;


		try
		{
			outStream = new FileOutputStream(destinationImageFile);

			if(!bitmap.hasAlpha())
			{
				// Save the created bitmap
				bitmap.compress(Bitmap.CompressFormat.JPEG, IMAGE_QUALITY, outStream);
			}
			else
			{
				bitmap.compress(Bitmap.CompressFormat.PNG, IMAGE_QUALITY, outStream);
			}

		}
		catch (IOException e)
		{
			Debug.error(CommonDefines.FILE_UTILS_TAG, "Error creating scaled bitmap " + e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if (freeBitmap)
				{
					if (!bitmap.isRecycled())
					{
						bitmap.recycle();
						bitmap = null;
						System.gc();
					}
				}

				if (outStream != null)
				{
					// Dispose the stream
					outStream.flush();
					outStream.close();
				}
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}

		return destinationImageFile.getAbsolutePath();
	}


	public static void limitImageToMaxResolution(Context context, int MAX_SIZE, Uri uri, Uri originalUri)
	{
		try
		{

			String imagePath = uri.getPath();
			final BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			BitmapFactory.decodeFile(imagePath, options);

			int imageWidth = options.outWidth;
			int imageHeight = options.outHeight;


			int sampleSize = 1;

			if (imageWidth > MAX_SIZE || imageHeight > MAX_SIZE)
			{
				int widthRatio = (int)Math.floor(imageWidth/(float)MAX_SIZE);
				int heightRatio = (int)Math.floor(imageHeight/(float)MAX_SIZE);

				if (widthRatio > 1 || heightRatio > 1)
				{
					if (heightRatio > widthRatio)
					{
						sampleSize = heightRatio;
					}
					else
					{
						sampleSize = widthRatio;
					}
				}
			}

			options.inJustDecodeBounds = false;


			//Sample size make it nearest largest powers of two
			sampleSize = Math.max((sampleSize/2) * 2, 1); //This will make value of 3 to 2 (so that we will have largest enclosed sampled bitmap)
			options.inSampleSize = sampleSize;

			File file = new File(uri.getPath());
			FileInputStream fileInputStream = new FileInputStream(file);

			Bitmap bitmap = BitmapFactory.decodeStream(fileInputStream, null, options);

			if (bitmap != null)
			{
				// Find out required scale factor now
				float scaleFactor = getScaleFactor(MAX_SIZE, bitmap.getWidth(), bitmap.getHeight());
				getScaledImagePathFromBitmap(bitmap, file.getParentFile(), file.getName(), scaleFactor, getBitmapOrientation(context, originalUri));
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

	}

	private static ExifInfo getBitmapOrientation(Context context, Uri uri)
	{
		int 	rotation 		= 0;
		boolean flipRequired 	= false;

		// Read exif data if any
		ExifInterface exif;
		try
		{
			exif = new ExifInterface(context.getContentResolver().openInputStream(uri));
			int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

			switch (orientation)
			{
				case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:
					flipRequired = true;
					break;

				case ExifInterface.ORIENTATION_FLIP_VERTICAL:
					flipRequired = true;
				case ExifInterface.ORIENTATION_ROTATE_180:
					rotation = 180;
					break;


				case ExifInterface.ORIENTATION_TRANSPOSE:
					flipRequired = true;
				case ExifInterface.ORIENTATION_ROTATE_90:
					rotation = 90;
					break;

				case ExifInterface.ORIENTATION_TRANSVERSE:
					flipRequired = true;
				case ExifInterface.ORIENTATION_ROTATE_270:
					rotation = 270;
					break;

				case ExifInterface.ORIENTATION_UNDEFINED:
					rotation = getOrientationFromMediaStore(context, uri);
					break;
				default:
					Debug.error("FileUtility", "Unknown Orientation in Exif : " + orientation);
					rotation = 0;
			}


		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		ExifInfo exifInfo = new ExifInfo(rotation, flipRequired);
		return exifInfo;
	}

	public static int getOrientationFromMediaStore(Context context, Uri uri)
	{
		String[] columns = {MediaStore.Images.Media.DATA, MediaStore.Images.Media.ORIENTATION};
		Cursor cursor = context.getContentResolver().query(uri, columns, null, null, null);
		if (cursor == null) return 0;

		cursor.moveToFirst();

		int orientationColumnIndex = cursor.getColumnIndex(columns[1]);
		int rotation = cursor.getInt(orientationColumnIndex);
		cursor.close();

		return rotation;
	}

	private static float getScaleFactor(int sizeRequired, int width, int height)
	{

		float scaleFactor = 1f;

		if (height > 0 && width > 0 && sizeRequired > 0)
		{
			if (width > sizeRequired || height > sizeRequired)
			{
				float aspect = width / (height * 1f);

				if (aspect > 1f)
				{
					scaleFactor = sizeRequired / (width * 1.0f);
				}
				else
				{
					scaleFactor = sizeRequired / (height * 1.0f);
				}
			}
		}

		return  scaleFactor;
	}

	public static String getMimeType(byte[] dataArray, int dataLength)
	{
		// Detect file type
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeByteArray(dataArray,0,dataLength,options);
		String mimeType = options.outMimeType;
		return mimeType;
	}
}


class ExifInfo
{
	private float rotation;
	private boolean isFlipped;

	public ExifInfo(float rotation, boolean isFlipped)
	{
		this.rotation       = rotation;
		this.isFlipped      = isFlipped;
	}

	public float getRotation()
	{
		return rotation;
	}

	public boolean isFlipped()
	{
		return isFlipped;
	}
}
