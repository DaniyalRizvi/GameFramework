package com.voxelbusters.nativeplugins.helpers;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.widget.Toast;

import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.helpers.interfaces.IPermissionRequestCallback;
import com.voxelbusters.nativeplugins.utilities.MiscUtilities;
import com.voxelbusters.nativeplugins.utilities.PermissionUtility;

import java.util.HashMap;

/**
 * Created by ayyappa on 23/09/17.
 */

public class PermissionRequestFragment extends Fragment
{
    public static final String PERMISSION_LIST      = "PermissionList";
    public static final String MESSAGE_INFO      = "MessageInfo";



    final int PERMISSIONS_REQUEST_CODE = 111;

    private IPermissionRequestCallback m_callback;
    private String infoMessage;


    HashMap<String, Boolean> beforeRequestRationale = new HashMap<>();
    HashMap<String, Boolean> afterRequestRationale  = new HashMap<>();

    public void setCallback(IPermissionRequestCallback callback)
    {
        m_callback = callback;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        String[] permissionList = getArguments().getStringArray(PERMISSION_LIST);
        infoMessage = getArguments().getString(MESSAGE_INFO);

        updateRequestRationaleStatus(beforeRequestRationale, permissionList);

        requestPermissions(permissionList, PERMISSIONS_REQUEST_CODE);

        if(beforeRequestRationale.containsValue(true))
        {
           // Toast.makeText(getActivity(), infoMessage,Toast.LENGTH_SHORT).show();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
    {
        boolean status = false;
        if (requestCode == PERMISSIONS_REQUEST_CODE)
        {
            boolean isNeverAskForStorageSelected = false;

            status = PermissionUtility.verifyPermissions(grantResults);

            if (!status) //Detection for Never Ask Again click
            {
                updateRequestRationaleStatus(afterRequestRationale, permissions);

                for(String eachPermission : permissions)
                {
                    boolean before  = beforeRequestRationale.get(eachPermission);
                    boolean after   = afterRequestRationale.get(eachPermission);

                    isNeverAskForStorageSelected = ((before == true && after == false) ||
                            (before == false && after == false));

                    if(isNeverAskForStorageSelected)
                        break;
                }

                if (isNeverAskForStorageSelected)
                {
                    if(permissions.length == 1)
                    {
                        Toast.makeText(getActivity(), "Please enable the permission from application settings.", Toast.LENGTH_SHORT).show();
                    }
                    else  if(permissions.length > 1)
                    {
                        Toast.makeText(getActivity(), "Please enable the permissions from application settings.", Toast.LENGTH_SHORT).show();
                    }
                }
                if(m_callback != null)
                {
                    m_callback.onPermissionDeny();
                }
            }
            else
            {
                if(m_callback != null)
                {
                    m_callback.onPermissionGrant();
                }
            }
        }

        FragmentTransaction fragmentTransaction = getActivity().getFragmentManager().beginTransaction();
        fragmentTransaction.remove(this);
        fragmentTransaction.commit();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    void updateRequestRationaleStatus (HashMap<String, Boolean> statusMap, String[] permissionList)
    {
        for(int i=0; i<permissionList.length ;i++ )
        {
            boolean needToShow = shouldShowRequestPermissionRationale(permissionList[i]);
            statusMap.put(permissionList[i], needToShow);
        }
    }
}