package com.voxelbusters.nativeplugins.features.billing.serviceprovider.amazon;


import android.content.Context;

import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.PurchasingService;
import com.amazon.device.iap.internal.model.UserDataBuilder;
import com.amazon.device.iap.model.FulfillmentResult;
import com.amazon.device.iap.model.Product;
import com.amazon.device.iap.model.ProductDataResponse;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.UserData;
import com.amazon.device.iap.model.UserDataResponse;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.features.billing.core.datatypes.BillingProduct;
import com.voxelbusters.nativeplugins.features.billing.core.datatypes.BillingTransaction;
import com.voxelbusters.nativeplugins.features.billing.core.interfaces.IBillingServiceListener;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.StringUtility;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Created by ayyappa on 25/03/16.
 */
public class AmazonPurchasingListener implements PurchasingListener
{
    IBillingServiceListener listener;
    ArrayList<Receipt> purchasedProducts =  new ArrayList<Receipt>();

    ArrayList<String> consumableProducts = new ArrayList<String>();
    ArrayList<String> nonConsumableProducts = new ArrayList<String>();

    UserData currentUserData;


    AmazonPurchasingListener(Context context, IBillingServiceListener listener)
    {
        this.listener = listener;

        UserDataBuilder builder = new UserDataBuilder();
        Locale currentLocale = context.getResources().getConfiguration().locale;
        builder.setMarketplace(currentLocale.getCountry());

        currentUserData = builder.build();

        Debug.log(CommonDefines.BILLING_TAG, "Default marketplace :" + currentUserData);
    }

    public boolean hasProduct(String productID)
    {
        if (consumableProducts.contains(productID) || nonConsumableProducts.contains(productID))
        {
            return  true;
        }
        else
        {
            return false;
        }
    }

    public boolean isConsumableProduct (String productID)
    {
        return  consumableProducts.contains(productID);
    }

    public boolean isProductPurchased(String productID)
    {
        if (purchasedProducts.size() != 0)
        {
            for (int i = 0; i < purchasedProducts.size(); i++) {

                Receipt eachPurchase = purchasedProducts.get(i);
                if (eachPurchase.getSku().equals(productID)) {
                    return true;
                }
            }
        }
        else
        {
            Debug.warning(CommonDefines.BILLING_TAG, "If restore purchases not yet done, Try restoring purchases first");
        }

        return  false;
    }

    @Override
    public void onUserDataResponse(UserDataResponse userDataResponse)
    {
        Debug.error(CommonDefines.BILLING_TAG, "User Details :" + userDataResponse.getUserData().toString());
        currentUserData = userDataResponse.getUserData();
    }

    @Override
    public void onProductDataResponse(ProductDataResponse productDataResponse)
    {
        ProductDataResponse.RequestStatus requestStatus = productDataResponse.getRequestStatus();

        if (requestStatus == ProductDataResponse.RequestStatus.FAILED || requestStatus == ProductDataResponse.RequestStatus.NOT_SUPPORTED)
        {
            String error = productDataResponse.toString();
            Debug.error(CommonDefines.BILLING_TAG, "OnQueryInventoryFailed! " + error);

            if (listener != null)
            {
                listener.onRequestProductsFinished(null, error);
            }
        }
        else
        {
            // Fetch all the results and send the message
            ArrayList<BillingProduct> detailsArray = new ArrayList<BillingProduct>();

            Map<String, Product> productMap = productDataResponse.getProductData();

            nonConsumableProducts.clear();
            consumableProducts.clear();

            for (String eachProductID : productMap.keySet())
            {
                Product eachDetails = productMap.get(eachProductID);
                if (eachDetails != null)
                {
                    BillingProduct product = new BillingProduct();
                    Debug.log(CommonDefines.BILLING_TAG, "Product Details [" + eachProductID + "]" + " : " + eachDetails.toString());
                    Debug.log(CommonDefines.BILLING_TAG, "User Details [" + eachProductID + "]" + " : " + PurchasingService.getUserData());

                    product.name 					= eachDetails.getTitle();
                    product.description 			= eachDetails.getDescription();
                    product.product_identifier 		= eachDetails.getSku();
                    product.localised_price 		= eachDetails.getPrice();

                    String countryCode              = currentUserData.getMarketplace();
                    String currencyCode             = StringUtility.getCurrencyCodeFromCountryCode(countryCode);
                    String currencySymbol           = StringUtility.getCurrencySymbolFromCode(currencyCode);
                    product.currency_code 			= currencyCode;
                    product.currency_symbol 		= currencySymbol;

                    String rawPrice                 = product.localised_price.replace(currencySymbol,"");
                    product.price_amount_micros 	= (long) (Float.parseFloat(rawPrice) * 1000000);


                    if (eachDetails.getProductType() == ProductType.ENTITLED)
                    {
                        nonConsumableProducts.add(eachDetails.getSku());
                    }
                    else if (eachDetails.getProductType() == ProductType.CONSUMABLE)
                    {
                        consumableProducts.add(eachDetails.getSku());
                    }
                    else
                    {
                        Debug.error(CommonDefines.BILLING_TAG, "This plugin won't support Subscriptions yet!");
                    }

                    detailsArray.add(product);
                }
            }

            if (listener != null)
            {
                listener.onRequestProductsFinished(detailsArray, null);
            }
        }
    }

    @Override
    public void onPurchaseResponse(PurchaseResponse purchaseResponse)
    {
        String status       = AmazonBillingHelper.getTransactionState(purchaseResponse.getRequestStatus());
        String requestId    = purchaseResponse.getRequestId().toString();

        if(status.equals(Keys.Billing.PurchaseState.PURCHASED))
        {
            Receipt receipt = purchaseResponse.getReceipt();
            String productID = receipt.getSku();

            // consume if required
            if (consumableProducts.contains(productID))
            {
                // Consume the product and send the callback
                PurchasingService.notifyFulfillment(receipt.getReceiptId(), FulfillmentResult.FULFILLED);

                ArrayList<BillingTransaction> list = new ArrayList<BillingTransaction>();
                list.add(AmazonBillingHelper.getBillingTransaction(receipt, purchaseResponse.getRequestStatus(), null));
                listener.onPurchaseTransactionFinished(list, null);
            }
            else
            {
                purchasedProducts.add(receipt);

                if (listener != null)
                {
                    ArrayList<BillingTransaction> list = new ArrayList<BillingTransaction>();
                    list.add(AmazonBillingHelper.getBillingTransaction(receipt, purchaseResponse.getRequestStatus(), null));
                    listener.onPurchaseTransactionFinished(list, null);
                }
            }
        }
        else
        {
            ArrayList<BillingTransaction> list = new ArrayList<BillingTransaction>();
            String error = "onBillingPurchaseFailed :" + purchaseResponse.toString();

            String productIdentifier = AmazonBillingHelper.GetProductIdentifierForRequest(requestId);
            AmazonBillingHelper.reportFailedTransaction(productIdentifier, error, listener);
        }

        // Remove the request information
        AmazonBillingHelper.RemoveBuyRequest(requestId);
    }

    @Override
    public void onPurchaseUpdatesResponse(PurchaseUpdatesResponse purchaseUpdatesResponse)
    {

        String error = null;
        ArrayList<BillingTransaction> transactionList = null;
        if (purchaseUpdatesResponse.getRequestStatus() == PurchaseUpdatesResponse.RequestStatus.SUCCESSFUL)
        {
            transactionList = new ArrayList<BillingTransaction>();

            List<Receipt> receiptList = purchaseUpdatesResponse.getReceipts();
            purchasedProducts.clear();

            for (int i = 0; i < receiptList.size(); i++)
            {
                Receipt eachPurchase = receiptList.get(i);
                String productID = eachPurchase.getSku();

                if (isConsumableProduct(productID))
                {
                    // Consume the product and send the callback
                    Debug.error(CommonDefines.BILLING_TAG, "Nullifying consumable product");
                    PurchasingService.notifyFulfillment(eachPurchase.getReceiptId(), FulfillmentResult.FULFILLED);
                    continue;
                }

                // Add to our cache list
                purchasedProducts.add(eachPurchase);

                BillingTransaction transaction 	= AmazonBillingHelper.getBillingTransaction(eachPurchase, PurchaseResponse.RequestStatus.ALREADY_PURCHASED, null);

                if (!transaction.transactionState.equals(Keys.Billing.PurchaseState.REFUNDED)) // If not refunded state, mark it restored.
                {
                    transaction.transactionState = Keys.Billing.PurchaseState.RESTORED;
                }

                transactionList.add(transaction);
            }
        }
        else
        {
            error = "Failed to fetch restored products : " + purchaseUpdatesResponse.toString();
        }

        listener.onRestoreTransactionFinished(transactionList, error);
    }
}