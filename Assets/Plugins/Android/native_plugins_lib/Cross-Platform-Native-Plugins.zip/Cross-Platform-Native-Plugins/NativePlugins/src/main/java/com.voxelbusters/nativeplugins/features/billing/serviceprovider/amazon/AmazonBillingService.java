package com.voxelbusters.nativeplugins.features.billing.serviceprovider.amazon;

import android.content.Context;

import com.amazon.device.iap.PurchasingService;
import com.amazon.device.iap.model.RequestId;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.features.billing.core.BasicBillingService;
import com.voxelbusters.nativeplugins.features.billing.core.interfaces.IBillingEvents;
import com.voxelbusters.nativeplugins.features.billing.core.interfaces.IBillingServiceListener;
import com.voxelbusters.nativeplugins.features.billing.serviceprovider.BillingResponseCodes;
import com.voxelbusters.nativeplugins.features.billing.serviceprovider.google.util.BillingResult;

import com.voxelbusters.nativeplugins.features.billing.serviceprovider.google.util.IabHelper;
import com.voxelbusters.nativeplugins.utilities.Debug;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class AmazonBillingService extends BasicBillingService
{
    public static AmazonBillingService instance = null;
    Context context;
    boolean isSetupDone = false;

    boolean isBillingSupported = false;

    ArrayList<String> consumableProducts = null;
    ArrayList<String> nonConsumableProducts = null;
    ArrayList<String> allProducts = new ArrayList<String>();
    boolean requestInventoryQueued = false;
    boolean requestRestorePurchasesQueued = false;

    AmazonPurchasingListener purchasingListener;

    //Returns singleton instance
    public static AmazonBillingService getInstance() {
        if (instance == null) {
            instance = new AmazonBillingService();
        }

        return instance;
    }

    private AmazonBillingService() {
        super();
    }

    @Override
    public void init(String key, Context context, String[] consumableList)
    {
        isSetupDone = false;
        this.context = context;
        consumableProducts = new ArrayList<String>(Arrays.asList(consumableList));
        startSetup();
    }

    //If setup not done, just start setup
    void startSetup()
    {
        if (!isSetupDone)
        {
            purchasingListener = new AmazonPurchasingListener(context, getListener());

            PurchasingService.registerListener(context, purchasingListener);
            isSetupDone = true;
            IBillingServiceListener listener = getListener();

            // Fetch user data on start
            PurchasingService.getUserData();


            if (listener != null)
            {
                listener.onSetupFinished(true);
            }

        }
    }



    @Override
    public void requestBillingProducts(String[] consumableProductIDs, String[] nonConsumableProductIDs)
    {
        if (!isSetupDone)
        {
            String error = "Please Call Init at start for billing setup";
            Debug.error(CommonDefines.BILLING_TAG, error);
            if (serviceListener != null) {
                serviceListener.onRequestProductsFinished(null, error);
            }
            return;
        }

        consumableProducts = new ArrayList<String>(Arrays.asList(consumableProductIDs));
        nonConsumableProducts = new ArrayList<String>(Arrays.asList(nonConsumableProductIDs));

        allProducts.clear();
        allProducts.addAll(consumableProducts);
        allProducts.addAll(nonConsumableProducts);

        if (isSetupDone)
        {
            // Request inventory
            requestInventoryInternal();
        }
        else
        {
            requestInventoryQueued = true;
        }
    }

    void requestInventoryInternal()
    {
        Set<String> set = new HashSet<String>(allProducts.size());
        set.addAll(allProducts);

        PurchasingService.getProductData(set);
    }

    @Override
    public void buyProduct(String productID, String developerPayload, Context context)
    {
        if (isSetupDone)
        {
            if (!purchasingListener.hasProduct(productID))//We need the product details as we are not aware if its consumable or not to auto consume
            {
                String error = "Item details not available. Request product details call is skipped. Its required to proceed!";

                Debug.error(CommonDefines.BILLING_TAG, error);

                AmazonBillingHelper.reportFailedTransaction(productID, error, getListener());
            }
            else
            {
                RequestId requestId =  PurchasingService.purchase(productID);
                AmazonBillingHelper.AddBuyRequest(requestId.toString(), productID);
            }
        }
        else
        {
            Debug.error(CommonDefines.BILLING_TAG, "Setup not yet finished!");
            AmazonBillingHelper.reportFailedTransaction(productID, "Setup not yet finished!", getListener());
        }
    }

    @Override
    public boolean isProductPurchased(String productID)
    {
        if (isSetupDone)
        {
            return  purchasingListener.isProductPurchased(productID);
        }
        else
        {
            Debug.error(CommonDefines.BILLING_TAG, "Please Call Init at start for billing setup");
        }

        return false;
    }

    @Override
    public void restoreCompletedTransactions()
    {
        if (!isSetupDone)
        {
            requestRestorePurchasesQueued = true;
            return;
        }

        PurchasingService.getPurchaseUpdates(true);
    }

    @Override
    protected void finalize() throws Throwable
    {
        super.finalize();
        Debug.log(CommonDefines.BILLING_TAG, "Disposing listeners");

        if (purchasingListener != null)
        {
            PurchasingService.registerListener(context, null);
            purchasingListener = null;
        }
    }

    public IBillingEvents.IBillingSetupFinishedListener getSetupFinishedListener()
    {
        IBillingEvents.IBillingSetupFinishedListener setupFinishedListener = new IBillingEvents.IBillingSetupFinishedListener()
        {
            @Override
            public void onBillingSetupFinished(BillingResult result)
            {


                IBillingServiceListener listener = getListener();

                if (!result.isSuccess())
                {
                    Debug.error(CommonDefines.BILLING_TAG, "Sorry, Billing not supported!" + result);
                    isBillingSupported = false;

                    if (listener != null)
                    {
                        listener.onSetupFinished(false);
                    }
                }
                else
                {
                    isSetupDone = true;

                    isBillingSupported = true;

                    if (requestInventoryQueued)//If its queued, finish  by calling it.
                    {
                        requestInventoryInternal();
                        requestInventoryQueued = false;
                    }

                    if (requestRestorePurchasesQueued)
                    {
                        restoreCompletedTransactions();
                        requestRestorePurchasesQueued = false;
                    }

                    if (listener != null)
                    {
                        listener.onSetupFinished(true);
                    }
                }

            }
        };

        return setupFinishedListener;
    }
}
